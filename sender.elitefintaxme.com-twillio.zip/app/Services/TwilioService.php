<?php

namespace App\Services;

use Twilio\Rest\Client;

class TwilioService
{
    protected $client;
    protected $from;

    public function __construct()
    {
        $sid = env('TWILIO_SID');
        $token = env('TWILIO_AUTH_TOKEN');
        $this->from = env('TWILIO_NUMBER');

        if ($sid && $token) {
            $this->client = new Client($sid, $token);
        }
    }

    /**
     * Format number to E.164 (ensure + and country code).
     *
     * @param string $number
     * @return string
     */
    protected function formatNumber($number)
    {
        $number = trim($number);
        
        // Remove spaces or dashes
        $number = str_replace([' ', '-', '(', ')'], '', $number);

        // If it starts with +, return as is
        if (substr($number, 0, 1) === '+') {
            return $number;
        }

        // If it's exactly 10 digits, assume US (+1)
        if (strlen($number) === 10 && is_numeric($number)) {
            return '+1' . $number;
        }

        // Otherwise, just prepend + if it's numeric and looks like a full number
        if (is_numeric($number)) {
            return '+' . $number;
        }

        return $number;
    }

    /**
     * Send an SMS message.
     *
     * @param string|array $to
     * @param string $message
     * @param string|null $callbackUrl
     * @return array
     */
    public function sendSms($to, $message, $callbackUrl = null)
    {
        if (!$this->client) {
            return [
                'success' => false,
                'message' => 'Twilio credentials not configured.'
            ];
        }

        $recipients = is_array($to) ? $to : [$to];
        $results = [];

        foreach ($recipients as $recipient) {
            try {
                $recipient = $this->formatNumber($recipient);
                $params = [
                    'from' => $this->from,
                    'body' => $message,
                ];

                if ($callbackUrl) {
                    $params['statusCallback'] = $callbackUrl;
                }

                $msg = $this->client->messages->create($recipient, $params);

                $results[] = [
                    'to' => $recipient,
                    'success' => true,
                    'sid' => $msg->sid,
                    'status' => $msg->status
                ];
            } catch (\Exception $e) {
                $results[] = [
                    'to' => $recipient,
                    'success' => false,
                    'error' => $e->getMessage()
                ];
            }
        }

        return $results;
    }

    /**
     * Initiate a voice call.
     *
     * @param string $to
     * @param string $twimlUrl
     * @param string|null $callbackUrl
     * @return array
     */
    public function makeCall($to, $twimlUrl, $callbackUrl = null)
    {
        if (!$this->client) {
            return [
                'success' => false,
                'message' => 'Twilio credentials not configured.'
            ];
        }

        try {
            $to = $this->formatNumber($to);
            $params = [
                'url' => $twimlUrl,
            ];

            if ($callbackUrl) {
                $params['statusCallback'] = $callbackUrl;
                $params['statusCallbackEvent'] = ['initiated', 'ringing', 'answered', 'completed'];
            }

            $call = $this->client->calls->create($to, $this->from, $params);

            return [
                'success' => true,
                'sid' => $call->sid,
                'status' => $call->status
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
}
