@extends('admin.layouts.app')

@section('title')
    {{ $messagesLog->customer ? $messagesLog->customer->owner_name : 'Conversation' }}
@endsection

@push('css')
<style>
    .chat-container {
        display: flex;
        flex-direction: column;
        height: calc(100vh - 250px);
        background: #efe7de;
        border-radius: 8px;
        overflow: hidden;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        position: relative;
    }
    .chat-container::before {
        content: "";
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        opacity: 0.05;
        background-image: url('https://user-images.githubusercontent.com/15075759/28719144-86dc0f70-73b1-11e7-911d-60d70fcded21.png');
        pointer-events: none;
    }
    .chat-messages {
        flex-grow: 1;
        overflow-y: auto;
        padding: 20px;
        display: flex;
        flex-direction: column;
        gap: 8px;
        z-index: 1;
    }
    .message-bubble {
        max-width: 75%;
        padding: 6px 12px 8px;
        border-radius: 8px;
        font-size: 14.5px;
        position: relative;
        box-shadow: 0 1px 1px rgba(0,0,0,0.1);
        word-wrap: break-word;
        line-height: 1.4;
    }
    .message-outbound {
        align-self: flex-end;
        background: #d9fdd3;
        color: #111b21;
        border-top-right-radius: 0;
    }
    .message-inbound {
        align-self: flex-start;
        background: #fff;
        color: #111b21;
        border-top-left-radius: 0;
    }
    .message-time {
        font-size: 11px;
        color: #667781;
        margin-top: 2px;
        text-align: right;
        margin-left: 20px;
        float: right;
    }
    .chat-footer {
        background: #f0f2f5;
        padding: 10px 15px;
        border-top: 1px solid #ddd;
        z-index: 1;
    }
    .chat-header-custom {
        background: #f0f2f5;
        padding: 10px 15px;
        border-bottom: 1px solid #ddd;
        display: flex;
        align-items: center;
        gap: 15px;
    }
    .avatar-small {
        width: 40px;
        height: 40px;
        background: #008069;
        color: #fff;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
    }
</style>
@endpush

@section('content')
    <div class="content">
        <div class="clearfix"></div>
        @include('flash::message')
        <div class="clearfix"></div>

        <div class="box box-primary">
            <div class="box-body no-padding">
                <div class="chat-header-custom">
                    <a href="{{ route('admin.messages-logs.index') }}" class="btn btn-default btn-sm">
                        <i class="fa fa-arrow-left"></i>
                    </a>
                    <div class="avatar-small">
                        {{ substr($messagesLog->customer ? $messagesLog->customer->owner_name : 'U', 0, 1) }}
                    </div>
                    <div>
                        <h4 style="margin: 0; font-weight: 600;">{{ $messagesLog->customer ? $messagesLog->customer->owner_name : 'Unknown Contact' }}</h4>
                        <small class="text-muted" id="contact-phone">{{ $messagesLog->customer ? $messagesLog->customer->phone : ($messagesLog->direction == 'outbound' ? $messagesLog->to_num : $messagesLog->from_num) }}</small>
                    </div>
                    <div style="margin-left: auto;">
                        <button type="button" class="btn btn-success btn-sm" id="btn-call" title="Call Contact">
                            <i class="fa fa-phone"></i>
                        </button>
                    </div>
                </div>
                
                <div class="chat-container">
                    <div class="chat-messages" id="chat-messages">
                        @forelse($messages as $msg)
                            <div class="message-bubble {{ $msg->direction == 'outbound' ? 'message-outbound' : 'message-inbound' }}">
                                {{ $msg->body }}
                                <span class="message-time">
                                    {{ $msg->created_at->format('H:i') }}
                                </span>
                            </div>
                        @empty
                            <div class="text-center text-muted" style="margin-top: 50px;">
                                No messages in this conversation.
                            </div>
                        @endforelse
                    </div>
                    
                    <div class="chat-footer">
                        <form action="{{ route('admin.messages-logs.store') }}" method="POST">
                            @csrf
                            <input type="hidden" name="customer_id" value="{{ $messagesLog->customer_id }}">
                            <input type="hidden" name="to_num[]" value="{{ $messagesLog->customer ? $messagesLog->customer->phone : ($messagesLog->direction == 'outbound' ? $messagesLog->to_num : $messagesLog->from_num) }}">
                            <input type="hidden" name="from_num" value="{{ $messagesLog->from_num }}">
                            <input type="hidden" name="direction" value="outbound">
                            <input type="hidden" name="status" value="pending">
                            
                            <div class="input-group">
                                <input type="text" name="body" placeholder="Type a message..." class="form-control" autocomplete="off" required>
                                <span class="input-group-btn">
                                    <button type="submit" class="btn btn-primary btn-flat">
                                        <i class="fa fa-paper-plane"></i> Send
                                    </button>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
<script>
    var chatMessages = document.getElementById('chat-messages');
    if(chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;

    $('#btn-call').on('click', function() {
        var phone = $('#contact-phone').text();
        var customerId = '{{ $messagesLog->customer_id }}';

        if(confirm('Do you want to initiate a voice call to ' + phone + '?')) {
            $.ajax({
                url: '{{ route("admin.messages-logs.initiate-call") }}',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    to_num: phone,
                    customer_id: customerId
                },
                success: function(response) {
                    if(response.success) {
                        alert(response.message);
                    } else {
                        alert('Error: ' + response.message);
                    }
                },
                error: function() {
                    alert('Failed to connect to server.');
                }
            });
        }
    });
</script>
@endpush