<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>{{ config('app.name') }}</title>
    <script>
        var firebaseConfig = {!! json_encode(\App\Helper\Util::getFromFirebaseRC()) !!}
    </script>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="icon" href="{{ asset('storage/logo-mini.png') }}" type="image/x-icon">

    <!-- Bootstrap WYSIHTML5 -->
    <link rel="stylesheet" href="{{ asset('css/admin/bootstrap3-wysihtml5.min.css') }}">


    <!-- Bootstrap 3.3.7 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

    <!-- Theme style -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.4.2/css/AdminLTE.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.4.2/css/skins/_all-skins.min.css">

    <!-- iCheck -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/iCheck/1.0.2/skins/square/_all.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">

    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/select2-bootstrap-theme/0.1.0-beta.10/select2-bootstrap.min.css">
    <!-- Bootstrap Toggle Switch -->
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css" rel="stylesheet">

    <!-- Custom Admin CSS -->
    <link href="{{ asset('css/admin/custom.css') }}" rel="stylesheet">

    {{--@yield('css')--}}
    @stack('css')

    {{-- firebase web push notification --}}
    <link rel="manifest" href="{{asset('manifest.json')}}">

    <!-- The core Firebase JS SDK is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/7.3.0/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/7.3.0/firebase-messaging.js"></script>

    <!-- TODO: Add SDKs for Firebase products that you want to use
         https://firebase.google.com/docs/web/setup#available-libraries -->
    <script src="https://www.gstatic.com/firebasejs/7.3.0/firebase-analytics.js"></script>
    <script src="{{asset('main.js')}}"></script>
    <script>
        function sendTokenToServer(currentToken) {
            if ("{{\Auth::check()}}" == "1") {
                var url = "{{URL::to('add-user-device')}}";
                var form_data = new FormData();
                form_data.append('device_type', 'web');
                form_data.append('device_token', currentToken);
                ajaxPost(url, form_data, (status, data) => {
                    if (status) {
                        localStorage.setItem('device-token', currentToken)
                    } else {
                    }
                })
            }

        }
    </script>
</head>

<body class="skin-blue sidebar-mini">
    @if (!Auth::guest())
        <div class="wrapper">
            <!-- Main Header -->
            <header class="main-header">
                <!-- Logo -->
                <a href="{{ url('/admin/home') }}" class="logo">
                    <span class="logo-mini">
                        <img src="{{ route('api.resize', ['img' => 'public/logo-mini.png', 'w=25', 'h=25']) }}">
                    </span>
                    <!-- logo for regular state and mobile devices -->
                    <span class="logo-lg">
                        <img src="{{ route('api.resize', ['img' => 'public/logo-mini.png', 'w=40', 'h=40']) }}">
                        {{ config('app.name') }}
                    </span>
                </a>
                <!-- Header Navbar -->
                <nav class="navbar navbar-static-top" role="navigation">
                    <!-- Sidebar toggle button-->
                    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
                        <span class="sr-only">Toggle navigation</span>
                    </a>
                    <!-- Navbar Right Menu -->
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <li class="dropdown notifications-menu">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
                                    <i class="fa fa-bell-o"></i>
                                    <span
                                        class="label label-warning notification-counter">{{count(\Auth::user()->unreadNotifications)}}</span>
                                </a>
                                <ul class="dropdown-menu">
                                    <li class="header">You have <span
                                            class="notification-counter">{{count(\Auth::user()->unreadNotifications)}}</span>
                                        notifications
                                        <small class="text-right pull-right"><a href="" id="mark-read">Mark All Read</a>
                                        </small>
                                    </li>
                                    <li>
                                        <!-- inner menu: contains the actual data -->
                                        <ul class="menu">
                                            @foreach(\Auth::user()->notifications as $key => $notification)
                                                <li>
                                                    <a
                                                        href="{{url("admin/" . \App\Models\Notification::$ACTION_TYPES[$notification->data['action_type']] . "/" . $notification->data['ref_id'])}}">
                                                        <i class="fa fa-bell-o text-red"></i>
                                                        {{$notification->data['message']}}
                                                    </a>
                                                </li>
                                            @endforeach
                                        </ul>
                                    </li>
                                    <li class="footer"><a href="{{url("admin/notifications")}}">View all</a></li>
                                </ul>
                            </li>
                            <!-- User Account Menu -->
                            <li class="dropdown user user-menu">
                                <!-- Menu Toggle Button -->
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <!-- The user image in the navbar-->
                                    <img src="{{ Auth::user()->details->image_url }}" class="user-image" alt="User Image" />
                                    <!-- hidden-xs hides the username on small devices so only the image appears. -->
                                    <span class="hidden-xs">{!! Auth::user()->name !!}</span>
                                </a>
                                <ul class="dropdown-menu">
                                    <!-- The user image in the menu -->
                                    <li class="user-header">
                                        <img src="{{ Auth::user()->details->image_url }}" class="user-image"
                                            alt="User Image" />
                                        <p>
                                            {!! Auth::user()->name !!}
                                            <small>Member since {!! Auth::user()->created_at->format('M. Y') !!}</small>
                                        </p>
                                    </li>
                                    <!-- Menu Footer-->
                                    <li class="user-footer">
                                        <div class="pull-left">
                                            <a href="{{ route('admin.users.profile') }}"
                                                class="btn btn-default btn-flat">Profile</a>
                                        </div>
                                        <div class="pull-right">
                                            <a href="{!! url('/admin/logout') !!}" class="btn btn-default btn-flat"
                                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                Sign out
                                            </a>

                                            <form id="logout-form" action="{{ url('/admin/logout') }}" method="POST"
                                                style="display: none;">
                                                {{ csrf_field() }}
                                            </form>
                                        </div>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>

            <!-- Left side column. contains the logo and sidebar -->
            @include('admin.layouts.sidebar')
            <!-- Content Wrapper. Contains page content -->
            <div class="content-wrapper">
                <section class="content-header clearfix" style="min-height:40px">
                    <h1 class="pull-left">@yield('title')</h1>
                    {{ Breadcrumbs::render(Route::currentRouteName()) }}
                </section>
                @yield('content')
            </div>
            <!-- Main Footer -->
            <footer class="main-footer" style="max-height: 100px;text-align: center">
                <strong>Copyright © {{ date('Y')  }} <a href="#">{{ config('app.name')  }}</a>.</strong> All rights
                reserved.
            </footer>
        </div>
    @else
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- Branding Image -->
                    <a class="navbar-brand" href="{!! url('/admin/') !!}">
                        {{ config('app.name')  }}
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <li><a href="{!! url('/admin/home') !!}">Home</a></li>
                    </ul>
                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <li><a href="{!! url('/admin/login') !!}">Login</a></li>
                        <li><a href="{!! url('/admin/register') !!}">Register</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        @yield('content')
                    </div>
                </div>
            </div>
        </div>
    @endif

    <!-- jQuery 3.1.1 -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--  Bootstrap Toogle switch-->
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>

    <!-- AdminLTE App -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/admin-lte/2.4.2/js/adminlte.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/iCheck/1.0.2/icheck.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <!-- SweetAlert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Morris JS -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>

    <!-- Bootstrap WYSIHTML5 -->
    <script src="{{ asset('js/admin/bootstrap3-wysihtml5.all.min.js') }}"></script>

    {{-- @yield('scripts')--}}
    @stack('scripts')
    <script src="{{ asset('js/admin/custom.js') }}"></script>
    <script>
        $(document).ready(function () {
            $("#mark-read").on('click', function (e) {
                e.preventDefault();
                {{\Auth::user()->unreadNotifications->markAsRead()}}
                $(".notification-counter").html(0);
            });
        });
        function loadProgress(total) {
            setInterval(function () {
                $.get("{{ route('admin.email.progress') }}", function (res) {
                    let percent = Math.round((res.sent / total) * 100);
                    $('#progressBar').css('width', percent + '%').text(percent + '%');
                });
            }, 2000);
        }


    </script>

    <script>
        $(function () {

            // Form submit intercept
            $('.ajax-post').on('submit', function (e) {
                e.preventDefault();

                let form = this;
                let fd = new FormData(form);

                $('#sendBox').show();
                $('#logList').html('<li>Uploading sheet...</li>');
                $('#progressBar').css('width', '0%').text('0%');

                $.ajax({
                    url: $(form).attr('action'),
                    method: $(form).attr('method') || 'POST',
                    data: fd,
                    processData: false,
                    contentType: false,
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    success: function (res) {
                        // IMPORTANT: store() should return JSON with total count
                        // Example: {status:true,total:600}
                        if (res.total) {
                            window.__TOTAL = res.total;
                            startPolling(res.total);
                            $('#logList').prepend('<li><b>Queued:</b> ' + res.total + ' emails</li>');
                        } else {
                            $('#logList').prepend('<li style="color:red;">Upload OK but total missing in response</li>');
                        }
                    },
                    error: function (xhr) {
                        $('#logList').prepend('<li style="color:red;">Error: ' + xhr.responseText + '</li>');
                    }
                });
            });

            function startPolling(total) {
                window.__poll = setInterval(function () {
                    $.get("{{ route('admin.emails.progress') }}", { total: total }, function (res) {

                        let percent = total > 0 ? Math.round((res.sent / total) * 100) : 0;
                        if (percent > 100) percent = 100;

                        $('#progressBar').css('width', percent + '%').text(percent + '%');

                        // Update logs list (latest 20)
                        if (res.logs) {
                            let html = '';
                            res.logs.forEach(function (row) {
                                let color = row.status === 'success' ? 'green' : 'red';
                                html += `<li style="color:${color}">${row.email} - ${row.status}${row.error ? ' - ' + row.error : ''}</li>`;
                            });
                            $('#logList').html(html);
                        }

                        // Stop when done
                        if (res.sent >= total) {
                            clearInterval(window.__poll);
                            $('#logList').prepend('<li><b>DONE:</b> Completed sending.</li>');
                        }
                    });
                }, 2000);
            }
        });
    </script>

    <script>
        $(function () {

            let pollTimer = null;
            let lastId = 0;
            let total = 0;

            function resetUI(t) {
                lastId = 0;
                total = t || 0;

                $("#sendPanel").show();
                $("#st_total").text(total);
                $("#st_sent").text(0);
                $("#st_success").text(0);
                $("#st_failed").text(0);

                $("#progressBar").css("width", "0%").text("0%");
                $("#logsTbody").html("");
            }

            function addRow(row) {
                let badge = row.status === 'success'
                    ? '<span class="label label-success">success</span>'
                    : '<span class="label label-danger">failed</span>';

                let error = row.error ? $('<div/>').text(row.error).html() : '';
                let email = $('<div/>').text(row.email).html();

                $("#logsTbody").append(`
            <tr>
                <td>${row.id}</td>
                <td>${email}</td>
                <td>${badge}</td>
                <td style="max-width:520px;word-break:break-word;">${error}</td>
                <td>${row.created_at ?? ''}</td>
            </tr>
        `);
            }

            function startPolling() {
                if (pollTimer) clearInterval(pollTimer);

                pollTimer = setInterval(function () {
                    $.get("{{ route('admin.emails.progress') }}", { total: total, last_id: lastId }, function (res) {

                        $("#st_total").text(res.total || total);
                        $("#st_sent").text(res.sent || 0);
                        $("#st_success").text(res.success || 0);
                        $("#st_failed").text(res.failed || 0);

                        let percent = (total > 0) ? Math.round((res.sent / total) * 100) : 0;
                        if (percent > 100) percent = 100;
                        $("#progressBar").css("width", percent + "%").text(percent + "%");

                        // append only new logs
                        if (res.logs && res.logs.length) {
                            res.logs.forEach(addRow);
                        }
                        lastId = res.last_id || lastId;

                        // stop when done
                        if (total > 0 && res.sent >= total) {
                            clearInterval(pollTimer);
                        }
                    });
                }, 2000);
            }

            // ✅ intercept only specified forms
            $(".ajax-post").on("submit", function (e) {
                e.preventDefault();

                let form = this;
                let fd = new FormData(form);

                // optional: disable submit
                $(form).find('button[type="submit"],input[type="submit"]').prop('disabled', true);

                $.ajax({
                    url: $(form).attr("action"),
                    method: $(form).attr("method") || "POST",
                    data: fd,
                    processData: false,
                    contentType: false,
                    headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
                    success: function (res) {
                        if (res.status) {
                            resetUI(res.total || 0);
                            startPolling();
                        } else {
                            alert("Upload failed");
                        }
                    },
                    error: function (xhr) {
                        console.log(xhr.responseText);
                        alert("Error: " + xhr.status);
                    },
                    complete: function () {
                        $(form).find('button[type="submit"],input[type="submit"]').prop('disabled', false);
                    }
                });
            });

        });
    </script>



</body>

</html>