{!! App\Helper\MenuHelper::staticGeneratePermittedMenus() !!}

















