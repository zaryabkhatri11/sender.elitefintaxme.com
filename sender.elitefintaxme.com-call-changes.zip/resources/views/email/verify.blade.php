<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>

<div>
    Hi {{ $name }},
    <br>
    We got a request to reset your {{ getenv('APP_NAME') }} password.
    <br>
    Your verification code : {{$verification_code}}
    <br>
    If you didn't request, please ignore this email.
    <br/>
</div>

</body>
</html>